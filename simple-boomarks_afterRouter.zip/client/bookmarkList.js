Template.bookmarkList.helpers({
	bookmarks:function () {
		return Bookmarks.find();
	}
})